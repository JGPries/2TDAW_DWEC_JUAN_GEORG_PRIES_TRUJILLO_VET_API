<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DUEÑOS1</title>
    <link rel="stylesheet" type="text/css" href="../css/stylo.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
    <link rel="manifest" href="../assets/site.webmanifest">
    <!--Para las imagenes del menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>

    <?php
        
        require_once("../php/funciones.php");

        $conexion=conectar();
        $parametro1="../";
        $parametro2="";
        generador_menu($parametro1,$parametro2);

    ?>

    <header>
        <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
    </header>

    <main class="maindiv">

        <h2 class="titindex">Nuevo dueño</h2>

        <form id="formnoticia" action="#" method="POST" enctype="multipart/form-data">

            Ingresa tu dni.
            <input type="text" name="Dni" required>
            <br>
            Añade tu nombre aquí.
            <input type="text" name="Nombre" required>
            <br>
            Telefono de contacto.(opcional)
            <input type="number" name="Telefono">
            <br>
            Añade tu nick por el que quieres que te vean.
            <input type="text" name="nick" required>
            <br>
            Inserta tu contraseña.
            <input type="password" name="pass" required>
            <br>
            <input type="submit" value="enviar" name="enviar">

        </form>

    </main>

    <?php

        if(isset($_POST['enviar'])){
            $Dni=$_POST['Dni'];
            $Nombre=$_POST['Nombre'];
            $Telefono=$_POST['Telefono'];
            $nick=$_POST['nick'];
            $pass=$_POST['pass'];

            $insertarDueño="INSERT into dueño values (?,?,?,?,md5(?))";

            $consulta=$conexion->prepare($insertarDueño);

            $consulta->bind_param("ssiss",$Dni,$Nombre,$Telefono,$nick,$pass);

            $consulta->execute();

            $consulta->close();

            echo" <meta http-equiv = 'refresh' content = '0;url=dueños.php'>";


        }

    ?>

    <?php

        generador_footer($parametro1,$parametro2);

        $conexion=desconectar();

    ?>

</body>
</html>