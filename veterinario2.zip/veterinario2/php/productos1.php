<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PRODUCTOS1</title>
    <!-- Conectar a css -->
    <link rel="stylesheet" type="text/css" href="../css/stylo.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
    <link rel="manifest" href="../assets/site.webmanifest">
    <!--Para las imagenes del menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>
    <?php
    
        require_once("../php/funciones.php");

        $conexion=conectar();
        $parametro1="../";
        $parametro2="";
        generador_menu($parametro1,$parametro2);

    ?>

        <header>
            <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
        </header>

    <main class="maindiv">

        <h2 class="titindex">Nuevo producto</h2>

        <form id="formnoticia" action="#" method="POST" enctype="multipart/form-data">

            Id que se le adjuntará al producto.
            <?php
                $insertarid="SELECT auto_increment
                from information_schema.tables
                where table_schema='veterinaria' and table_name='producto'";

                $idCliente=$conexion->query($insertarid);

                $fila=$idCliente->fetch_array();

                echo"<input type='text' readonly name='idProd' value='$fila[auto_increment]'>";
                
            ?>
            <br>
            Añade el nombre del producto.
            <input type="text" name="nombre" required>
            <br>
            Añade el precio del producto.<br>
            <input type="number" name="precio" required>
            <br>
            <input type="submit" value="enviar" name="enviar">

        </form>

    </main>

    <?php

        if(isset($_POST['enviar'])){
            $nombre=$_POST['nombre'];
            $precio=$_POST['precio'];

            $insertarProducto="insert into producto values (null,?,?)";

            $consulta=$conexion->prepare($insertarProducto);

            $consulta->bind_param("sd",$nombre,$precio);

            $consulta->execute();

            $consulta->close();

            echo" <meta http-equiv = 'refresh' content = '0;url=productos.php'>";

        }

    ?>

    <?php

            generador_footer($parametro1,$parametro2);
    
            $conexion=desconectar();
    
        ?>
</body>
</html>