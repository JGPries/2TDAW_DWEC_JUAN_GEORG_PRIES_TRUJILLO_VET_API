<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DUEÑOS</title>
    <link rel="stylesheet" type="text/css" href="../css/stylo.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
    <link rel="manifest" href="../assets/site.webmanifest">
    <!--Para las imagenes del menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>

    <?php
        
        require_once("../php/funciones.php");

        $conexion=conectar();
        $parametro1="../";
        $parametro2="";
        generador_menu($parametro1,$parametro2);

    ?>

    <header>
        <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
    </header>

    <main class="maindiv">

        <h2 class="titindex">DUEÑOS</h2>
        
        <?php

            if(isset($_COOKIE['lasesh'])){

                if($_SESSION['Nombre']=='admin'){

                    echo"<form class='formbusca' action='#' method='POST' enctype='multipart/form-data'>
                    Buscar dueño <input type='search' name='busqueda' placeholder='nombre del dueño/nick/telefono'>
                    <input type='submit' name='busc' value='buscar'>
                    </form>
            
                    <a href='dueños1.php'><button class='butt'>Añadir dueños</button></a>";

                }
            }

        ?>

        <?php

            if(isset($_COOKIE['lasesh'])){

                if($_SESSION['Nombre']=='admin'){

                    if(isset($_POST['busc'])){
                        $buscado=$_POST['busqueda'];
                        $consul = "SELECT * from dueño where Nombre='$buscado' or nick='$buscado' or Telefono='$buscado' or Nombre!='Administrador'";

                        $datos1=$conexion->query($consul);

                        if(!$datos1){
                            echo"error";
                        }else{
                            echo
                                "<table id='tcliente1'>
                                    <tr>
                                        <th>DNI</th>
                                        <th>NOMBRE</th>
                                        <th>TELEFONO</th>
                                        <th>NICK</th>
                                    </tr>
                                ";

                            while($fila1=$datos1->fetch_array(MYSQLI_BOTH)){
                                echo
                                    "<tr>
                                        <td>$fila1[Dni]</td>
                                        <td>$fila1[Nombre]</td>
                                        <td>$fila1[Telefono]</td>
                                        <td>$fila1[nick]</td>
                                        <td>
                                            <form action='dueños2.php' method='POST' enctype='multipart/form-data'>
                                                <input type='submit' value='modificar' name='idmod'>
                                                <input type='hidden' value='$fila1[Dni]' name='idbusc'>
                                            </form>
                                        </td>
                                    </tr>
                                    ";
                            }
                            echo"</table>";
                        
                        }

                    }else{
                        $sentencia="SELECT * from dueño";
                        $datos=$conexion->query($sentencia);

                        if(!$datos){
                            echo"error";
                        }else{

                            if($datos->num_rows<=0){
                                echo"<br><h2>No hay dueños para mostrar</h2>";
                            }else{

                                echo
                                    "<table id='tcliente1'>
                                        <tr>
                                        <th>DNI</th>
                                        <th>NOMBRE</th>
                                        <th>TELEFONO</th>
                                        <th>NICK</th>
                                        </tr>
                                    ";

                                while($fila=$datos->fetch_array(MYSQLI_ASSOC)){
                                    echo
                                        "<tr>
                                            <td>$fila[Dni]</td>
                                            <td>$fila[Nombre]</td>
                                            <td>$fila[Telefono]</td>
                                            <td>$fila[nick]</td>
                                            <td>
                                                <form action='dueños2.php' method='POST' enctype='multipart/form-data'>
                                                    <input type='submit' value='modificar' name='idmod'>
                                                    <input type='hidden' name='idbusc' value='$fila[Dni]'>
                                                </form>
                                            </td>
                                        </tr>
                                        ";
                                }
                                echo"</table>";
                            }
                        }
                    }
                }else{

                    $misDatos="SELECT Nombre, Telefono, nick, Dni FROM dueño WHERE nick='$_SESSION[Nombre]'";

                    $datos2=$conexion->query($misDatos);

                    if(!$datos2){
                        echo"error";
                    }else{

                        if($datos2->num_rows<=0){
                            echo"<br><h2>No hay dueños para mostrar</h2>";
                        }else{

                            echo
                                "<table id='tcliente1'>
                                    <tr>
                                    <th>DNI</th>
                                    <th>NOMBRE</th>
                                    <th>TELEFONO</th>
                                    <th>NICK</th>
                                    </tr>
                                ";

                            while($fila2=$datos2->fetch_array(MYSQLI_ASSOC)){
                                echo
                                    "<tr>
                                        <td>$fila2[Dni]</td>
                                        <td>$fila2[Nombre]</td>
                                        <td>$fila2[Telefono]</td>
                                        <td>$fila2[nick]</td>
                                        <td>
                                            <form action='dueños2.php' method='POST' enctype='multipart/form-data'>
                                                <input type='submit' value='modificar' name='idmod'>
                                                <input type='hidden' name='idbusc' value='$fila2[Dni]'>
                                            </form>
                                        </td>
                                    </tr>
                                    ";
                            }
                            echo"</table>";
                        }
                    }

                }
            }

        ?>

    </main> 

    <?php

        generador_footer($parametro1,$parametro2);

        $conexion=desconectar();

    ?>

</body>
</html>