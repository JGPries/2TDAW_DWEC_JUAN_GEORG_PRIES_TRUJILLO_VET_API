<?php

    header('Content-Type: application/json');
    header("Access-Control-Allow-Origin: *");
    require_once("../php/funciones.php");
  
    $conexion=conectar();

    //EL IF ES PARA PROBARLO A MANO
    //EN TEORIA EL FORMULARIO COMPRUEBA QUE LOS DATOS SON CORRECTOS 

    if(isset($_REQUEST['titulo']) && 
        isset($_REQUEST['contenido']) && 
        isset($_REQUEST['foto']) && 
        isset($_REQUEST['fecha_publicacion'])){

        $titulo = $_REQUEST['titulo'];
        $contenido = $_REQUEST['contenido'];
        $imagen = $_REQUEST['foto'];
        $fecha_publicacion= $_REQUEST['fecha_publicacion'];
        
        $sentencia=$conexion->prepare("INSERT INTO 
                                            noticia 
                                            VALUES (null, ?,?,?,?)");
        $sentencia->bind_param("ssss",$titulo,
                                    $contenido,
                                    $imagen,
                                    $fecha_publicacion);
        
        $sentencia->execute();
        $filas_afectadas = $sentencia->affected_rows;
        
        if($filas_afectadas == 1){
            echo "$conexion->insert_id";
        }else{
            echo "false";
        }
        
    }else{
        echo "false";
    }

?>