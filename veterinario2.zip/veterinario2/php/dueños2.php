<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DUEÑOS2</title>
    <link rel="stylesheet" type="text/css" href="../css/stylo.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
    <link rel="manifest" href="../assets/site.webmanifest">
    <!--Para las imagenes del menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>

    <?php
        
        require_once("../php/funciones.php");

        $conexion=conectar();
        $parametro1="../";
        $parametro2="";
        generador_menu($parametro1,$parametro2);

    ?>

    <header>
        <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
    </header>

    <main class="maindiv">

        <h2 class="titindex">Modificar Dueños</h2>
        
        <?php
            
            if(isset($_COOKIE['lasesh'])){

                if($_SESSION['Nombre']=='admin'){

                    if(isset($_POST['idmod'])){
                        $pasoid=$_POST['idbusc'];
            
                        $sentencia="SELECT * from dueño where Dni='$pasoid'";

                        $datos=$conexion->query($sentencia);

                        if($datos->num_rows<=0){
                            echo"<br><h2>No hay dueños para mostrar</h2>";
                        }else{
                            $fila=$datos->fetch_array();
                            if($datos->num_rows>0){
                                echo"<form id='formnoticia' action='#' method='POST' enctype='multipart/form-data'>

                                        DNI del dueño
                                        <input type='text' value='$fila[Dni]'>
                                        <br>
                                        Nombre actual.
                                        <input type='text' name='Nombre' value='$fila[Nombre]'>
                                        <br>
                                        Telefono actual del dueño.
                                        <input type='number' name='Telefono' value='$fila[Telefono]'>
                                        <br>
                                        Tu nick actual.
                                        <input type='text' name='nick' value='$fila[nick]'>
                                        <br>
                                        Contraseña actual.
                                        <input type='password' name='foton' value='$fila[pass]'>
                                        <br>
                                        <input type='submit' value='enviar' name='enviar'>
                                        <input type='hidden' value='$fila[Dni]' name='idbusc'>
                                    </form>";
                            }
                        }   
                    }

                    if(isset($_POST['enviar'])){
                        $Dni=$_POST['Dni'];
                        $Nombre=$_POST['Nombre'];
                        $Telefono=$_POST['Telefono'];
                        $nick=$_POST['nick'];
                        $pass=$_POST['pass'];

                        $pasoid=$_POST['idbusc'];

                        $modificarDueño="UPDATE dueño set Dni=? , Nombre=? , Telefono=? , nick=? , pass=? where Dni='$pasoid'";

                        $consulta=$conexion->prepare($modificarDueño);

                        $consulta->bind_param("ssiss",$Dni,$Nombre,$Telefono,$nick,$pass);

                        $consulta->execute();

                        $consulta->close();

                        echo" <meta http-equiv = 'refresh' content = '0;url=dueños.php'>";

                    }

                }else{

                    if(isset($_POST['idmod'])){
                        $pasoid=$_POST['idbusc'];
            
                        $sentencia="SELECT * from dueño where Dni='$pasoid'";

                        $datos=$conexion->query($sentencia);

                        if($datos->num_rows<=0){
                            echo"<br><h2>No hay dueños para mostrar</h2>";
                        }else{
                            $fila=$datos->fetch_array();
                            if($datos->num_rows>0){
                                echo"<form id='formnoticia' action='#' method='POST' enctype='multipart/form-data'>

                                        DNI del dueño
                                        <input type='text' value='$fila[Dni]' readonly>
                                        <br>
                                        Nombre actual.
                                        <input type='text' name='Nombre' value='$fila[Nombre]' readonly>
                                        <br>
                                        Telefono actual del dueño.
                                        <input type='number' name='Telefono' value='$fila[Telefono]'>
                                        <br>
                                        Tu nick actual.
                                        <input type='text' name='nick' value='$fila[nick]' readonly>
                                        <br>
                                        Contraseña actual.
                                        <input type='password' name='foton' value='$fila[pass]'>
                                        <br>
                                        <input type='submit' value='enviar' name='enviar'>
                                        <input type='hidden' value='$fila[Dni]' name='idbusc'>
                                    </form>";
                            }
                        }   
                    }

                    if(isset($_POST['enviar'])){
                        $Dni=$_POST['Dni'];
                        $Nombre=$_POST['Nombre'];
                        $Telefono=$_POST['Telefono'];
                        $nick=$_POST['nick'];
                        $pass=$_POST['pass'];

                        $pasoid=$_POST['idbusc'];

                        $modificarDueño="UPDATE dueño set Dni=? , Nombre=? , Telefono=? , nick=? , pass=? where Dni='$pasoid'";

                        $consulta=$conexion->prepare($modificarDueño);

                        $consulta->bind_param("ssiss",$Dni,$Nombre,$Telefono,$nick,$pass);

                        $consulta->execute();

                        $consulta->close();

                        echo" <meta http-equiv = 'refresh' content = '0;url=dueños.php'>";

                    }

                }
            }

        ?>

    </main>


    <?php

        generador_footer($parametro1,$parametro2);

        $conexion=desconectar();

    ?>

</body>
</html>