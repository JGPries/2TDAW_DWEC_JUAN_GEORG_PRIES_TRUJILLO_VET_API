<?php

    //Cabeceras
	header('Content-Type: application/json');
	header("Access-Control-Allow-Origin: *");
    require_once("../php/funciones.php");
    
    $conexion=conectar();
    
    $datos=[];
    $sentencia=$conexion->query("SELECT * FROM noticia");
        
    while($fila=$sentencia->fetch_assoc()){ 
        	$datos[]=$fila;
    }
    
    echo json_encode($datos);

?>