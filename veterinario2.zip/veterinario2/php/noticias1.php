<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NOTICIAS1</title>
    <link rel="stylesheet" type="text/css" href="../css/stylo.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
    <link rel="manifest" href="../assets/site.webmanifest">
    <!--Para las imagenes del menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>

    <?php
    
        require_once("../php/funciones.php");

        $conexion=conectar();
        $parametro1="../";
        $parametro2="";
        generador_menu($parametro1,$parametro2);

    ?>

        <header>
            <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
        </header>

    <main class="maindiv">

        <h2 class="titindex">Nueva Noticia</h2>

        <form id="formnoticia" action="#" method="POST" enctype="multipart/form-data">

            Id que se le adjuntará.
            <?php
                $insertarid="SELECT auto_increment
                from information_schema.tables
                where table_schema='veterinaria' and table_name='noticia'";

                $idNoticia=$conexion->query($insertarid);

                $fila1=$idNoticia->fetch_array();

                echo"<input type='text' readonly name='idTest' value='$fila1[auto_increment]'>";
                
            ?>
            <br>
            Añade el título de la noticia.
            <input type="text" name="titulo" required>
            <br>
            Añade el contenido de la noticia.<br>
            <textarea rows="10" cols="60" maxlength="1000" name="contenido" required></textarea>
            <br>
            Añade la foto de la noticia.
            <input type="file" name="foton" required>
            <br>
            Añade la fecha de la noticia.
            <input type="date" name="fecha_publicacion" required>
            <br>
            <input type="submit" value="enviar" name="enviar">

        </form>

    </main>

    <?php

        if(isset($_POST['enviar'])){
            $titulo=$_POST['titulo'];
            $contenido=$_POST['contenido'];
            $fecha_publicacion=$_POST['fecha_publicacion'];

            
            $name = $_FILES['foton']['name'];
            $temp = $_FILES['foton']['tmp_name'];

            if(!file_exists("../assets/noticia")){
                mkdir("../assets/noticia");
            }

            $ruta="../assets/noticia/$name";
            move_uploaded_file ($temp, $ruta);

            $insertarNoticia="insert into noticia values (null,?,?,?,?)";

            $consulta=$conexion->prepare($insertarNoticia);

            $consulta->bind_param("ssss",$titulo,$contenido,$ruta,$fecha_publicacion);

            $consulta->execute();

            $consulta->close();

            echo" <meta http-equiv = 'refresh' content = '0;url=noticias.php'>";

        }

    ?>

    <?php

            generador_footer($parametro1,$parametro2);
    
            $conexion=desconectar();
    
        ?>

</body>
</html>