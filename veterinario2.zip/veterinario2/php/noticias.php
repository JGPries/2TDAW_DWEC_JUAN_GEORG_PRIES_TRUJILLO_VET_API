<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>NOTICIAS</title>
        <!-- Conectar a css -->
        <link rel="stylesheet" type="text/css" href="../css/stylo.css">
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
        <link rel="manifest" href="../assets/site.webmanifest">
        <!--Para las imagenes del menu-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <script type="text/javascript" src="../js/noticias_app.js" defer ></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php
    
            require_once("../php/funciones.php");
    
            $conexion=conectar();
            $parametro1="../";
            $parametro2="";
            generador_menu($parametro1,$parametro2);
    
        ?>
    
        <header>
            <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
        </header>
    
        <main class="maindiv">
    
            <h2 class="titindex">NOTICIAS</h2>
            
            <?php

                if($_COOKIE!=0){
                    if(isset($_COOKIE['lasesh'])){

                        if($_SESSION['Nombre']=='admin'){

                            echo"<input type='button' id='btnAñadir' value='Añadir noticia' class='w-25 btn btn-danger'>";  

                        }
                    }

                }else{

                    echo"
                    
                        <form id='insertar_f' class='d-none mx-auto w-50 mt-3'>
            
                            <div class='form-group'>
                                <label for='titulo'>Título</label>
                                <input type='text' id='titulo' name='titulo' class='form-control'>
                            </div>
                            <br>
                            <div class='form-group'>
                                <label for='contenido'>Contenido</label>
                                <textarea rows='10' cols='60' maxlength='1000' name='contenido' id='contenido' class='form-control'></textarea>
                            </div>
                            <br>
                            <div class='form-group'>
                                <label for='foto'>Foto</label>
                                <input type='text' id='foto' name='foto' class='form-control'>
                            </div>
                            <br>
                            <div class='form-group'>
                                <label for='fecha'>Fecha</label>
                                <input type='date' id='fecha_publicacion' name='fecha_publicacion' class='form-control'>
                            </div>
                            <br>
                            <input id='nuevo' type='submit' name='nuevo' value='Nueva noticia' class='btn btn-primary btn-block'>
            
                        </form>
            
            
                        <div class='container' id='cartaNoticias'>
            
                        </div>

                    ";

                }

            ?>

            <!-- <input type='button' id='btnAñadir' value='Añadir noticia' class='w-25 btn btn-danger'> -->

                    

            <!-- formulario para insertar -->
            <form id="insertar_f" class="d-none mx-auto w-50 mt-3">

                <div class="form-group">
                    <label for="titulo">Título</label>
                    <input type="text" id="titulo" name="titulo" class="form-control">
                </div>
                <br>
                <div class="form-group">
                    <label for="contenido">Contenido</label>
                    <textarea rows="10" cols="60" maxlength="1000" name="contenido" id="contenido" class="form-control"></textarea>
                </div>
                <br>
                <div class="form-group">
                    <label for="foto">Foto</label>
                    <input type="text" id="foto" name="foto" class="form-control">
                </div>
                <br>
                <div class="form-group">
                    <label for="fecha">Fecha</label>
                    <input type="date" id="fecha_publicacion" name="fecha_publicacion" class="form-control">
                </div>
                <br>
                <input id="nuevo" type="submit" name="nuevo" value="Nueva noticia" class="btn btn-primary btn-block">

            </form>

            <!-- fin del formulario de insertar -->

            <!-- Para mostrar las noticias -->

            <div class="container" id="cartaNoticias">

            </div>
    
        </main>
    
    
        <?php
            
            generador_footer($parametro1,$parametro2);
    
            $conexion=desconectar();
    
        ?>
    
    </body>
    
</html>