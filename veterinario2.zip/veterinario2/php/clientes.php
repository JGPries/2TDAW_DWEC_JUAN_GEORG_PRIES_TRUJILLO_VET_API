<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CLIENTES</title>
        <!-- Conectar a css -->
        <link rel="stylesheet" type="text/css" href="../css/stylo.css">
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
        <link rel="manifest" href="../assets/site.webmanifest">
        <!--Para las imagenes del menu-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="preconnect" href="https://fonts.gstatic.com">
    </head>
    <body>
        <?php

            require_once("../php/funciones.php");

            $conexion=conectar();
            $parametro1="../";
            $parametro2="";
            generador_menu($parametro1,$parametro2);

        ?>

        <header>
            <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
        </header>

        <main class="maindiv">

            
            <br>
            <h2 class="titindex">CLIENTES</h2>
            
            <?php
                if(isset($_COOKIE['lasesh'])){

                    if($_SESSION['Nombre']=='admin'){

                        echo"<form class='formbusca' action='#' method='POST' enctype='multipart/form-data'>
                        Buscar cliente <input type='search' name='busqueda' placeholder='nombre de la mascota/nick del dueño/telefono'>
                        <input type='submit' name='busc' value='buscar'>
                        </form>
            
                        <a href='clientes1.php'><button class='butt'>Añadir clientes</button></a>
                        ";

                    }
                }
            ?>

            <?php

                if(isset($_COOKIE['lasesh'])){

                    if($_SESSION['Nombre']=='admin'){

                        if(isset($_POST['busc'])){
                            $buscado=$_POST['busqueda'];
                            $consul = "SELECT c.foto, c.nombre, c.tipo, c.edad, d.nick, c.id from cliente c, dueño d where c.Dni_dueño=d.Dni AND d.nick='$buscado' or c.nombre='$buscado' or d.telefono='$buscado'";

                            $datos1=$conexion->query($consul);

                            if(!$datos1){
                                echo"error";
                            }else{
                                echo
                                    "<table id='tcliente1'>
                                        <tr>
                                            <th>FOTO</th>
                                            <th>MASCOTA</th>
                                            <th>TIPO</th>
                                            <th>EDAD</th>
                                            <th>NICK DUEÑO</th>
                                        </tr>
                                    ";

                                while($fila1=$datos1->fetch_array(MYSQLI_BOTH)){
                                    echo
                                        "<tr>
                                            <td><img id='fcliente' src='../assets/cliente/$fila1[foto]'></td>
                                            <td>$fila1[nombre]</td>
                                            <td>$fila1[tipo]</td>
                                            <td>$fila1[edad]</td>
                                            <td>$fila1[nick]</td>
                                            <td>
                                                <form action='clientes2.php' method='POST' enctype='multipart/form-data'>
                                                    <input type='submit' value='modificar' name='idmod'>
                                                    <input type='hidden' value='$fila1[id]' name='idbusc'>
                                                </form>
                                            </td>
                                        </tr>
                                        ";
                                }
                                echo"</table>";
                            
                            }

                        }else{

                            $sentencia="SELECT c.foto, c.nombre, c.tipo, c.edad, d.nick, c.id from cliente c, dueño d where c.Dni_dueño=d.Dni";
                            $datos=$conexion->query($sentencia);
            
                            if(!$datos){
                                echo"error";
                            }else{
            
                                if($datos->num_rows<=0){
                                    echo"<br><h2>No hay clientes para mostrar</h2>";
                                }else{
            
                                    echo
                                        "<table id='tcliente1'>
                                            <tr>
                                                <th>FOTO</th>
                                                <th>MASCOTA</th>
                                                <th>TIPO</th>
                                                <th>EDAD</th>
                                                <th>NICK DUEÑO</th>
                                            </tr>
                                        ";
            
                                    while($fila=$datos->fetch_array(MYSQLI_ASSOC)){
                                        echo
                                            "<tr>
                                                <td><img id='fcliente' src='../assets/cliente/$fila[foto]'></td>
                                                <td>$fila[nombre]</td>
                                                <td>$fila[tipo]</td>
                                                <td>$fila[edad]</td>
                                                <td>$fila[nick]</td>
                                                <td>
                                                    <form action='clientes2.php' method='POST' enctype='multipart/form-data'>
                                                        <input type='submit' value='modificar' name='idmod'>
                                                        <input type='hidden' name='idbusc' value='$fila[id]'>
                                                    </form>
                                                </td>
                                            </tr>
                                            ";
                                    }
                                    echo"</table>";
                                }
                            }
                        }
                    }else{

                        $misMascotas="SELECT c.nombre,c.edad,c.tipo,c.foto,d.Nombre,d.nick, c.id FROM cliente c,dueño d WHERE c.Dni_dueño=d.Dni AND d.nick='$_SESSION[Nombre]'";

                        $datos2=$conexion->query($misMascotas);

                        if(!$datos2){
                            echo"error";
                        }else{
        
                            if($datos2->num_rows<=0){
                                echo"<br><h2>No tienes mascotas registradas actualmente.</h2>";
                            }else{
        
                                echo
                                    "<table id='tcliente1'>
                                        <tr>
                                            <th>FOTO</th>
                                            <th>MASCOTA</th>
                                            <th>TIPO</th>
                                            <th>EDAD</th>
                                            <th>NICK DUEÑO</th>
                                        </tr>
                                    ";
        
                                while($fila2=$datos2->fetch_array(MYSQLI_ASSOC)){
                                    echo
                                        "<tr>
                                            <td><img id='fcliente' src='../assets/cliente/$fila2[foto]'></td>
                                            <td>$fila2[nombre]</td>
                                            <td>$fila2[tipo]</td>
                                            <td>$fila2[edad]</td>
                                            <td>$fila2[nick]</td>
                                        </tr>
                                        ";
                                }
                                echo"</table>";
                            }
                        }
                    }
                }
                
            ?>

        </main>


        <?php
    
            generador_footer($parametro1,$parametro2);

            $conexion=desconectar();

        ?>

    </body>
    
</html>