<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CITAS</title>
        <!-- Conectar a css -->
        <link rel="stylesheet" type="text/css" href="../css/stylo.css">
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
        <link rel="manifest" href="../assets/site.webmanifest">
        <!--Para las imagenes del menu-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>
<?php
        
        require_once("../php/funciones.php");

        $conexion=conectar();
        $parametro1="../";
        $parametro2="";
        generador_menu($parametro1,$parametro2);

    ?>

        <header>
            <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
        </header>

    <main class="maindiv">

        <h2 class="titindex">Nueva cita</h2>

        <form id="formnoticia" action="#" method="POST" enctype="multipart/form-data">

            Añade el nombre del cliente.
            <br>
            <?php
                $consulta1="SELECT * from cliente";

                $consul1=$conexion->query($consulta1);

                echo"<select name='cliente'>";
                while($fila=$consul1->fetch_array()){
                    echo"<option value='$fila[id]'>$fila[nombre]</option>";
                }
                echo"</select>";

            ?>

            <br>
            Añade el servicio.
            <br>
            <?php

                $consulta2="SELECT * from servicio";

                $consul2=$conexion->query($consulta2);
                echo"<select name='servicio'>";
                while($fila1=$consul2->fetch_array()){
                    echo"<option value='$fila1[id]'>$fila1[descripcion]</option>";
                }
                echo"</select>";

            ?>

            <br>
            Añade la fecha de la cita.
            <input type="date" name="fecha" required>
            <br>
            Añade la hora de la cita.
            <input type="time" name="hora" required>
            <br>
            <input type="submit" value="enviar" name="enviar">

        </form>

    </main>

    <?php

        if(isset($_POST['enviar'])){
            $cliente=$_POST['cliente'];
            $servicio=$_POST['servicio'];
            $fecha=$_POST['fecha'];
            $hora=$_POST['hora'];

            $insertarCitas="insert into citas values (?,?,?,?)";

            $consulta=$conexion->prepare($insertarCitas);

            $consulta->bind_param("iiss",$cliente,$servicio,$fecha,$hora);

            $consulta->execute();

            $consulta->close();

            echo" <meta http-equiv = 'refresh' content = '0;url=citas.php'>";

        }

    ?>

    <?php

        generador_footer($parametro1,$parametro2);

        $conexion=desconectar();

    ?>
</body>
</html>