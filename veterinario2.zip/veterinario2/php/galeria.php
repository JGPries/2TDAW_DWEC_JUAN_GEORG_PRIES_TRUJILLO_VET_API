<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PRODUCTOS</title>
        <!-- Conectar a css -->
        <link rel="stylesheet" type="text/css" href="../css/stylo.css">
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
        <link rel="manifest" href="../assets/site.webmanifest">
        <!--Para las imagenes del menu-->
        <script type="text/javascript" src="../js/galeria_app.js" defer ></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="preconnect" href="https://fonts.gstatic.com">
        
    </head>
    <body>
        <?php
    
            require_once("../php/funciones.php");
    
            $conexion=conectar();
            $parametro1="../";
            $parametro2="";
            generador_menu($parametro1,$parametro2);
    
        ?>
    
        <header>
            <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
        </header>
    
        <main class="maindiv">
    
            <h2 class="titindex">Galeria</h2>
            
            <div class="container" id="galeriaExt">

                

            </div>

            
    
        </main>
    
    
        <?php
            
            generador_footer($parametro1,$parametro2);
    
            $conexion=desconectar();
    
        ?>
    
    </body>
    
</html>