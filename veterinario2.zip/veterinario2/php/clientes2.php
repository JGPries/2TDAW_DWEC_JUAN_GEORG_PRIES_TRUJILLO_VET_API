<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CLIENTES2</title>
    <link rel="stylesheet" type="text/css" href="../css/stylo.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
    <link rel="manifest" href="../assets/site.webmanifest">
    <!--Para las imagenes del menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>
    <?php
        
        require_once("../php/funciones.php");

        $conexion=conectar();
        $parametro1="../";
        $parametro2="";
        generador_menu($parametro1,$parametro2);

    ?>

    <header>
        <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
    </header>

    <main class="maindiv">

        <h2 class="titindex">Modificar Clientes</h2>
        
        <?php
            
            if(isset($_POST['idmod'])){
                $pasoid=$_POST['idbusc'];
    
                $sentencia="SELECT * from cliente where id='$pasoid'";

                $datos=$conexion->query($sentencia);

                if($datos->num_rows<=0){
                    echo"<br><h2>No hay clientes para mostrar</h2>";
                }else{
                    $fila=$datos->fetch_array();
                    if($datos->num_rows>0){
                        echo"<form id='formnoticia' action='#' method='POST' enctype='multipart/form-data'>

                                ID del cliente
                                <input type='text' readonly value='$fila[id]'>
                                <br>
                                Añade el tipo de la mascota.
                                <input type='text' name='tipo' value='$fila[tipo]'>
                                <br>
                                Añade el nombre de la mascota.
                                <input type='text' name='nombre1' value='$fila[nombre]'>
                                <br>
                                Añade la edad de la mascota.
                                <input type='number' name='edad' value='$fila[edad]'>
                                <br>
                                Añade el nick del dueño.
                                <input type='text' name='nombre2' value='$fila[Dni_dueño]'>
                                <br>
                                Añade foto de la mascota.
                                <input type='file' name='foton' value='$fila[foto]'>
                                <br>
                                <input type='submit' value='enviar' name='enviar'>
                                <input type='hidden' value='$fila[id]' name='idbusc'>
                            </form>";
                    }
                }   
            }

            if(isset($_POST['enviar'])){
                $tipo=$_POST['tipo'];
                $nombre1=$_POST['nombre1'];
                $edad=$_POST['edad'];
                $nombre2=$_POST['nombre2'];

                $pasoid=$_POST['idbusc'];

                if($_FILES['foton']['size']>0){

                    $name = $_FILES['foton']['name'];
                    $temp = $_FILES['foton']['tmp_name'];

                    if(!file_exists("../assets/cliente")){
                        mkdir("../assets/cliente");
                    }

                    if($_FILES["foton"]["type"]==="image/jpg"){
                        $name=$name.".jpg";
                    }elseif($_FILES["foton"]["type"]==="image/png"){
                        $name=$name.".png"; 
                    }elseif($_FILES["foton"]["type"]==="image/gif"){
                        $name=$name.".gif";
                    }

                    $ruta="../assets/cliente/$name";
                    move_uploaded_file ($temp, $ruta);
    
                }else{
    
                    $oldpic="SELECT foto from cliente where id='$pasoid'";

                    $oldp=$conexion->query($oldpic);
                    $datos=$oldp->fetch_array();

                    $fotito=$datos['foto'];
    
                }

                

                $insertarid="SELECT auto_increment
                            from information_schema.tables
                            where table_schema='veterinaria' and table_name='cliente'";


                $modificarCliente="UPDATE cliente set tipo=? , nombre=? , edad=? , Dni_dueño=? , foto=? where id='$pasoid'";

                $consulta=$conexion->prepare($modificarCliente);

                $consulta->bind_param("ssiss",$tipo,$nombre1,$edad,$nombre2,$name);

                $consulta->execute();

                $consulta->close();

                echo" <meta http-equiv = 'refresh' content = '0;url=clientes.php'>";

            }

        ?>

    </main>


    <?php

        generador_footer($parametro1,$parametro2);

        $conexion=desconectar();

    ?>

</body>
</html>