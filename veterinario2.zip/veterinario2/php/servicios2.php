<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SERVICIOS2</title>
    <!-- Conectar a css -->
    <link rel="stylesheet" type="text/css" href="../css/stylo.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
    <link rel="manifest" href="../assets/site.webmanifest">
    <!--Para las imagenes del menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>

    <?php
        
        require_once("../php/funciones.php");

        $conexion=conectar();
        $parametro1="../";
        $parametro2="";
        generador_menu($parametro1,$parametro2);

    ?>

    <header>
        <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
    </header>

    <main class="maindiv">

        <h2 class="titindex">Modificar Servicios</h2>
        
        <?php
            
            if(isset($_POST['idbusc'])){
                $pasoid=$_POST['idbusc'];
    
                $sentencia="SELECT * from servicio where id='$pasoid'";

                $datos=$conexion->query($sentencia);

                if($datos->num_rows<=0){
                    echo"<br><h2>No hay servicios para mostrar</h2>";
                }else{
                    $fila=$datos->fetch_array();
                    if($datos->num_rows>0){
                        echo"<form id='formnoticia' action='#' method='POST' enctype='multipart/form-data'>

                                Añade una descripción del servicio.
                                <input type='text' name='descripcion' value='$fila[descripcion]'>
                                <br>
                                Añade la duración del servicio.<br>
                                <input type='number' name='duracion' value='$fila[duracion]'>
                                <br>
                                Añade el precio del servicio.<br>
                                <input type='number' name='precio' value='$fila[precio]'>
                                <br>
                                <input type='submit' value='enviar' name='enviar'>
                                <input type='hidden' value='$fila[id]' name='idbusc'>
                            </form>";
                    }
                }
            }
        ?>

        <?php

            if(isset($_POST['enviar'])){
                $descripcion=$_POST['descripcion'];
                $duracion=$_POST['duracion'];
                $precio=$_POST['precio'];
                
                $insertarid="SELECT auto_increment
                            from information_schema.tables
                            where table_schema='veterinaria' and table_name='servicio'";


                $modificarServicio="UPDATE servicio set descripcion=? , duracion=? , precio=? where id='$pasoid'";

                $consulta=$conexion->prepare($modificarServicio);

                $consulta->bind_param("sdd",$descripcion,$duracion,$precio);

                $consulta->execute();

                $consulta->close();

                echo" <meta http-equiv = 'refresh' content = '0;url=servicios.php'>";

            }

        ?>

    </main>


    <?php

        generador_footer($parametro1,$parametro2);

        $conexion=desconectar();

    ?>

</body>
</html>