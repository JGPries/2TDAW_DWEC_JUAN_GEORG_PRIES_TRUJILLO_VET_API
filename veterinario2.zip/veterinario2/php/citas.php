<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CITAS</title>
        <!-- Conectar a css -->
        <link rel="stylesheet" type="text/css" href="../css/stylo.css">
        <!-- Favicon -->
        <link rel="apple-touch-icon" sizes="180x180" href="../assets/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="../assets/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="../assets/favicon-16x16.png">
        <link rel="manifest" href="../assets/site.webmanifest">
        <!--Para las imagenes del menu-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="preconnect" href="https://fonts.gstatic.com">
    </head>
    <body>

        <?php
    
            require_once("../php/funciones.php");
    
            $conexion=conectar();
            $parametro1="../";
            $parametro2="";
            generador_menu($parametro1,$parametro2);
    
        ?>
    
        <header>
            <img id="fondopant" src="../assets/fondopantalla2.jpg" style="z-index:-5;">
        </header>
    
        <main class="maindiv">
    
            <h2 class="titindex">CALENDARIO</h2>
                   
            <?php

                $dias_semana=["Lunes","Martes","Miercoles","Jueves","Viernes","Sabado","Domingo"];

                $dia=date('d');
                $mes=date('m');
                $año=date('Y');

                if(isset($_POST['volver'])){

                    $año=$_POST['añoAnterior'];

                    $mes=$_POST['mesAnterior'];

                }elseif(isset($_POST['siguiente'])){

                    $año=$_POST['añoSiguiente'];
                    $mes=$_POST['mesSiguiente'];

                }

                $añoAnterior=$año;
                $añoSiguiente=$año;
                $mesAnterior=$mes-1;
                $mesSiguiente=$mes+1;

                if(($mes-1)<1){

                    $añoAnterior=$año-1;
                    $mesAnterior=12;

                }elseif(($mes+1)>12){

                    $mesSiguiente=1;
                    $añoSiguiente=$año+1;

                }

                $contsegundos=mktime(0,0,0,$mes,1,$año);
                $m_actual=date('t',$contsegundos);
                $d_actual=date('N',$contsegundos);

                setlocale(LC_ALL,"es-ES");
                $nommes=strftime("%B",$contsegundos);

                $celda=0;

                echo("<table  id='calend'><tr>");

                echo"
                <tr>
                    <th>
                        <form action='#' method='POST' enctype='multipart/form-data'>
                            <input type='submit' value='volver' name='volver'>
                            <input type='hidden' value='$añoAnterior' name='añoAnterior'>
                            <input type='hidden' value='".$mesAnterior."' name='mesAnterior'>
                        </form>
                    </th>
                ";
                echo"
                        <th colspan='5'></th>
                        <th>
                            <form action='#' method='POST' enctype='multipart/form-data'>
                                <input type='submit' value='siguiente' name='siguiente'>
                                <input type='hidden' value='$añoSiguiente' name='añoSiguiente'>
                                <input type='hidden' value='".$mesSiguiente."' name='mesSiguiente'>
                            </form>
                        </th>
                    </tr>"; 

                echo("<tr><th colspan='7'>$año $nommes</th></tr>");

                for($dias=0;$dias<7;$dias++){
                    echo("<th>$dias_semana[$dias]</th>");
                    $celda++;
                    if($celda==7){
                        echo("</tr><tr>");
                        $celda=0;
                    }
                }

                for($i=1;$i<$d_actual;$i++){
                    echo"<td></td>";
                    $celda++;
                    if($celda==7){
                        echo("</tr><tr>");
                        $celda=0;
                    }
                }

                for($i=1;$i<=$m_actual;$i++){
                    echo("<td>$i</td>");
                    $celda++;
                    if($celda==7){
                        echo("</tr><tr>");
                        $celda=0;
                    }
                }

                echo"</table>";

            ?>
    
            <h2 class="titindex">CITAS</h2>

            <?php
                if(isset($_COOKIE['lasesh'])){

                    if($_SESSION['Nombre']=='admin'){

                        echo"<a href='citas2.php'><button class='butt'>Añadir Cita</button></a>";

                        echo"<form class='formbusca' action='#' method='POST' enctype='multipart/form-data'>
                        Buscar cita <input type='search' name='busqueda' placeholder='cliente/servicio/fecha'>
                        <input type='submit' name='busc' value='buscar'>
                        </form>";

                    }
                }
            ?>

            <?php

                if(isset($_COOKIE['lasesh'])){

                    if($_SESSION['Nombre']=='admin'){

                        $fechAct=date('Y-m-d');

                        if(isset($_POST['busc'])){
                            $buscado=$_POST['busqueda'];

                            $consul="SELECT c.nombre , s.descripcion , ci.fecha ,ci.hora , ci.cliente , ci.servicio
                                    from citas ci , cliente c , servicio s
                                    where c.id=ci.cliente and s.id=ci.servicio and c.nombre = '$buscado' or s.descripcion = '$buscado' or ci.fecha = '$buscado' order by fecha ASC";

                            $datos1=$conexion->query($consul);

                            if(!$datos1){
                                echo"error";
                            }else{
            
                                if($datos1->num_rows<=0){
                                    echo"<br><h2>No hay citas para mostrar</h2>";
                                }else{
            
                                    echo
                                        "<table id='tablacli'>
                                            <tr>
                                                <th>CLIENTE</th>
                                                <th>SERVICIO</th>
                                                <th>FECHA</th>
                                                <th>HORA</th>
                                            </tr>
                                        ";
            
                                    while($fila1=$datos1->fetch_array(MYSQLI_BOTH)){
                                        if($fechAct<$fila1['fecha']){
                                            echo
                                                "<tr>
                                                    <td>$fila1[nombre]</td>
                                                    <td>$fila1[descripcion]</td>
                                                    <td>$fila1[fecha]</td>
                                                    <td>$fila1[hora]</td>
                                                    <td>
                                                        <form action='#' method='POST' enctype='multipart/form-data'>
                                                            <input type='submit' value='borrar' name='idborrar'>
                                                            <input type='hidden' value='$fila1[cliente]' name='borrarC'>
                                                            <input type='hidden' value='$fila1[servicio]' name='borrarD'>
                                                            <input type='hidden' value='$fila1[fecha]' name='borrarF'>
                                                            <input type='hidden' value='$fila1[hora]' name='borrarH'>
                                                        </form> 
                                                    </td>
                                                </tr>
                                            ";
                                        }else{
                                            echo
                                                "<tr>
                                                    <td>$fila1[nombre]</td>
                                                    <td>$fila1[descripcion]</td>
                                                    <td>$fila1[fecha]</td>
                                                    <td>$fila1[hora]</td>
                                                </tr>
                                            ";
                                        }
                                        
                                    }
                                    echo"</table>";
                                }
                            }

                        }else{

                            $sentencia="SELECT c.nombre , s.descripcion , ci.fecha , ci.hora , ci.cliente , ci.servicio
                                    from citas ci , cliente c , servicio s
                                    where c.id = ci.cliente and s.id = ci.servicio order by fecha ASC";

                            $datos=$conexion->query($sentencia);

                            if(!$datos){
                                echo"error";
                            }else{

                                if($datos->num_rows<=0){
                                    echo"<br><h2>No hay citas para mostrar</h2>";
                                }else{

                                    echo
                                        "<table id='tablacli'>
                                            <tr>
                                                <th>CLIENTE</th>
                                                <th>SERVICIO</th>
                                                <th>FECHA</th>
                                                <th>HORA</th>
                                            </tr>
                                        ";

                                    while($fila=$datos->fetch_array(MYSQLI_BOTH)){

                                        if($fechAct<$fila['fecha']){

                                            echo
                                                "<tr>
                                                    <td>$fila[nombre]</td>
                                                    <td>$fila[descripcion]</td>
                                                    <td>$fila[fecha]</td>
                                                    <td>$fila[hora]</td>
                                                    <td>
                                                        <form action='#' method='POST' enctype='multipart/form-data'>
                                                            <input type='submit' value='borrar' name='idborrar'>
                                                            <input type='hidden' value='$fila[cliente]' name='borrarC'>
                                                            <input type='hidden' value='$fila[servicio]' name='borrarD'>
                                                            <input type='hidden' value='$fila[fecha]' name='borrarF'>
                                                            <input type='hidden' value='$fila[hora]' name='borrarH'>
                                                        </form> 
                                                    </td>
                                                </tr>
                                            ";

                                        }else{
                                            echo
                                                "<tr>
                                                    <td>$fila[nombre]</td>
                                                    <td>$fila[descripcion]</td>
                                                    <td>$fila[fecha]</td>
                                                    <td>$fila[hora]</td>
                                                </tr>
                                            ";
                                        }
                                        
                                    }
                                    echo"</table>";
                                }
                            }

                        }

                        if(isset($_POST['idborrar'])){

                            $borrarC=$_POST['borrarC'];
                            $borrarD=$_POST['borrarD'];
                            $borrarF=$_POST['borrarF'];
                            $borrarH=$_POST['borrarH'];

                            $borrarCl="DELETE from citas where cliente='$borrarC' and servicio='$borrarD' and fecha='$borrarF' and hora = '$borrarH' ";

                            $datos=$conexion->query($borrarCl);

                    
                        }

                    }else{

                        $fechAct=date('Y-m-d');

                        $misCitas="SELECT c.nombre , s.descripcion , ci.fecha ,ci.hora , ci.cliente , ci.servicio, d.nick, d.Dni, c.Dni_dueño
                                from citas ci , cliente c , servicio s, dueño d
                                where c.id=ci.cliente and s.id=ci.servicio and d.Dni=c.Dni_dueño and d.nick='$_SESSION[Nombre]' order by fecha ASC";

                        $datos2=$conexion->query($misCitas);

                        if(!$datos2){
                            echo"<h2>error</h2>";
                        }else{
            
                            if($datos2->num_rows<=0){
                                echo"<br><h2>No tienes citas para mostrar</h2>";
                            }else{
            
                                echo
                                    "<table id='tablacli'>
                                        <tr>
                                            <th>CLIENTE</th>
                                            <th>SERVICIO</th>
                                            <th>FECHA</th>
                                            <th>HORA</th>
                                        </tr>
                                    ";
            
                                    while($fila2=$datos2->fetch_array(MYSQLI_BOTH)){
                                        if($fechAct<$fila2['fecha']){
                                            echo
                                                "<tr>
                                                    <td>$fila2[nombre]</td>
                                                    <td>$fila2[descripcion]</td>
                                                    <td>$fila2[fecha]</td>
                                                    <td>$fila2[hora]</td>
                                                </tr>
                                            ";
                                        }
                                    }
                                    echo"</table>";
                            }
                        }

                    }
                }
  
            ?>


        </main>
    
    
        <?php
           
            generador_footer($parametro1,$parametro2);
    
            $conexion=desconectar();
    
        ?>
    
    </body>
    
</html>