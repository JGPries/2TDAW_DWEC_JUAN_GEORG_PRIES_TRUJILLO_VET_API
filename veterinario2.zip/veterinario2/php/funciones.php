
<?php

    function conectar(){

        $conexion = new mysqli("localhost","root","","veterinaria");
        $conexion->set_charset("utf8");

        return $conexion;

    }
    
    function desconectar(){

        $conexion = new mysqli("localhost","root","","veterinaria");
        $conexion->set_charset("utf8");

        $conexion->close();

        return $conexion;

    }

    function generador_menu($parametro1="../",$parametro2=""){


        if(!isset($_SESSION['Nombre'])){

            echo " <div class='navmenu'> 
            <a href='$parametro1"."index.php'>VET</a>
            <a href='$parametro2"."productos.php'>PRODUCTOS</a>
            <a href='$parametro2"."servicios.php'>SERVICIOS</a>
            <a href='$parametro2"."noticias.php'>NOTICIAS</a>
            <a href='$parametro2"."galeria.php'>GALERIA</a>
            <a href='$parametro2"."acceder.php'>INICIAR SESIÓN</a>
            </div>";

        }elseif($_SESSION['Nombre']!="admin"){

            echo " <div class='navmenu'> 
            <a href='$parametro1"."index.php'>VET</a>
            <a href='$parametro2"."clientes.php'>Mis Mascotas</a>
            <a href='$parametro2"."dueños.php'>Mis Datos Personales</a>
            <a href='$parametro2"."citas.php'>Mis Citas</a>
            <a href='$parametro2"."noticias.php'>NOTICIAS</a>
            <a href='$parametro2"."galeria.php'>GALERIA</a>
            <a href='$parametro2"."productos.php'>PRODUCTOS</a>
            <a href='$parametro2"."servicios.php'>SERVICIOS</a>
            <a href='$parametro2"."cerrarSesion.php'>CERRAR SESIÓN</a>
            </div>";

        }elseif($_SESSION['Nombre']=="admin"){

            echo " <div class='navmenu'> 
            <a href='$parametro1"."index.php'>VET</a>
            <a href='$parametro2"."clientes.php'>CLIENTES</a>
            <a href='$parametro2"."dueños.php'>DUEÑOS</a>
            <a href='$parametro2"."productos.php'>PRODUCTOS</a>
            <a href='$parametro2"."servicios.php'>SERVICIOS</a>
            <a href='$parametro2"."testimonios.php'>TESTIMONIOS</a>
            <a href='$parametro2"."noticias.php'>NOTICIAS</a>
            <a href='$parametro2"."galeria.php'>GALERIA</a>
            <a href='$parametro2"."citas.php'>CITAS</a>
            <a href='$parametro2"."cerrarSesion.php'>CERRAR SESIÓN</a>
            </div>";

        }


    }

    function generador_footer($parametro1="../",$parametro2=""){

        if(!isset($_SESSION['Nombre'])){

            echo 
            "<footer id='footer'>
                <div class='enlacesfooter'>
                    <h2>Mapa de la Web</h2>
                    <ul>
                        <a href='$parametro1"."index.php'>VET</a>
                        <a href='$parametro2"."productos.php'>PRODUCTOS</a>
                        <a href='$parametro2"."servicios.php'>SERVICIOS</a>
                    </ul> 
                </div> 
                <div class='enlacesfooter'>
                    <h2>About us</h2>
                    <ul>
                        <a href='https://www.royalcanin.com/es' target='_blank'><li>Royal Canin</li></a>
                        <a href='https://www.hillspet.es/' target='_blank'><li>Hillspet</li></a>
                        <a href='https://mascotasonlineblog.wordpress.com/' target='_blank'><li>Blog</li></a>
                        <a href='https://www.hogarmania.com/mascotas/' target='_blank'><li>Hogarmania</li></a>
                    </ul> 
                </div> 
                <div class='enlacesfooter'>
                    <h2>Datos Fiscales</h2>
                    <ul>
                        <li>© Copyright 2021</li>
                        <li>Todos los derechos reservados</li>
                        <li>RoyalCanin</li>
                        <li>Hillspet</li>
                        <li>Hogarmania</li>
                    </ul> 
                </div> 
                <div class='enlacesfooter'>
                    <h2>Redes Sociales</h2>
                    <ul>
                        <a href='https://twitter.com/login?lang=es' target='_blank'><li>TWITTER <i class='fab fa-twitter' title='Twitter'></i></li></a>
                        <a href='https://www.reddit.com/login/' target='_blank'><li>REDDIt <i class='fab fa-reddit' title='REDDIT'></i></li></a>
                        <a href='https://www.instagram.com/' target='_blank'><li>INSTAGRAM <i class='fab fa-instagram' title='Instagram'></i></li></a>
                        <a href='mailto:juangeorgpriestrujillo@gmail.com' target='_blank'><li>GMAIL <i class='far fa-envelope' title='Gmail'></i></li></a>
                    </ul> 
                </div> 
            </footer>";

        }elseif($_SESSION['Nombre']!="admin"){

            echo 
                "<footer id='footer'>
                    <div class='enlacesfooter'>
                        <h2>Mapa de la Web</h2>
                        <ul>
                            <a href='$parametro1"."index.php'>VET</a>
                            <a href='$parametro2"."clientes.php'>Mis Mascotas</a>
                            <a href='$parametro2"."dueños.php'>Mis Datos Personales</a>
                            <a href='$parametro2"."citas.php'>Mis Citas</a>
                            <a href='$parametro2"."productos.php'>PRODUCTOS</a>
                            <a href='$parametro2"."servicios.php'>SERVICIOS</a>
                        </ul> 
                    </div> 
                    <div class='enlacesfooter'>
                        <h2>About us</h2>
                        <ul>
                            <a href='https://www.royalcanin.com/es' target='_blank'><li>Royal Canin</li></a>
                            <a href='https://www.hillspet.es/' target='_blank'><li>Hillspet</li></a>
                            <a href='https://mascotasonlineblog.wordpress.com/' target='_blank'><li>Blog</li></a>
                            <a href='https://www.hogarmania.com/mascotas/' target='_blank'><li>Hogarmania</li></a>
                        </ul> 
                    </div> 
                    <div class='enlacesfooter'>
                        <h2>Datos Fiscales</h2>
                        <ul>
                            <li>© Copyright 2021</li>
                            <li>Todos los derechos reservados</li>
                            <li>RoyalCanin</li>
                            <li>Hillspet</li>
                            <li>Hogarmania</li>
                        </ul> 
                    </div> 
                    <div class='enlacesfooter'>
                        <h2>Redes Sociales</h2>
                        <ul>
                            <a href='https://twitter.com/login?lang=es' target='_blank'><li>TWITTER <i class='fab fa-twitter' title='Twitter'></i></li></a>
                            <a href='https://www.reddit.com/login/' target='_blank'><li>REDDIt <i class='fab fa-reddit' title='REDDIT'></i></li></a>
                            <a href='https://www.instagram.com/' target='_blank'><li>INSTAGRAM <i class='fab fa-instagram' title='Instagram'></i></li></a>
                            <a href='mailto:juangeorgpriestrujillo@gmail.com' target='_blank'><li>GMAIL <i class='far fa-envelope' title='Gmail'></i></li></a>
                        </ul> 
                    </div> 
                </footer>";

        }elseif($_SESSION['Nombre']=="admin"){

            echo 
                "<footer id='footer'>
                    <div class='enlacesfooter'>
                        <h2>Mapa de la Web</h2>
                        <ul>
                            <a href='$parametro1"."index.php'>VET</a>
                            <a href='$parametro2"."clientes.php'>CLIENTES</a>
                            <a href='$parametro2"."dueños.php'>DUEÑOS</a>
                            <a href='$parametro2"."productos.php'>PRODUCTOS</a>
                            <a href='$parametro2"."servicios.php'>SERVICIOS</a>
                            <a href='$parametro2"."testimonios.php'>TESTIMONIOS</a>
                            <a href='$parametro2"."noticias.php'>NOTICIAS</a>
                            <a href='$parametro2"."citas.php'>CITAS</a>
                        </ul> 
                    </div> 
                    <div class='enlacesfooter'>
                        <h2>About us</h2>
                        <ul>
                            <a href='https://www.royalcanin.com/es' target='_blank'><li>Royal Canin</li></a>
                            <a href='https://www.hillspet.es/' target='_blank'><li>Hillspet</li></a>
                            <a href='https://mascotasonlineblog.wordpress.com/' target='_blank'><li>Blog</li></a>
                            <a href='https://www.hogarmania.com/mascotas/' target='_blank'><li>Hogarmania</li></a>
                        </ul> 
                    </div> 
                    <div class='enlacesfooter'>
                        <h2>Datos Fiscales</h2>
                        <ul>
                            <li>© Copyright 2021</li>
                            <li>Todos los derechos reservados</li>
                            <li>RoyalCanin</li>
                            <li>Hillspet</li>
                            <li>Hogarmania</li>
                        </ul> 
                    </div> 
                    <div class='enlacesfooter'>
                        <h2>Redes Sociales</h2>
                        <ul>
                            <a href='https://twitter.com/login?lang=es' target='_blank'><li>TWITTER <i class='fab fa-twitter' title='Twitter'></i></li></a>
                            <a href='https://www.reddit.com/login/' target='_blank'><li>REDDIt <i class='fab fa-reddit' title='REDDIT'></i></li></a>
                            <a href='https://www.instagram.com/' target='_blank'><li>INSTAGRAM <i class='fab fa-instagram' title='Instagram'></i></li></a>
                            <a href='mailto:juangeorgpriestrujillo@gmail.com' target='_blank'><li>GMAIL <i class='far fa-envelope' title='Gmail'></i></li></a>
                        </ul> 
                    </div> 
                </footer>";
                
        }
    }

?>