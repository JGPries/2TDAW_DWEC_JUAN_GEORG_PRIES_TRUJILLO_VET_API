-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-02-2022 a las 15:41:48
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `veterinaria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `citas`
--

CREATE TABLE `citas` (
  `cliente` bigint(20) UNSIGNED NOT NULL,
  `servicio` bigint(20) UNSIGNED NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `citas`
--

INSERT INTO `citas` (`cliente`, `servicio`, `fecha`, `hora`) VALUES
(7, 2, '2022-02-21', '14:10:00'),
(8, 3, '2021-10-17', '12:10:00'),
(9, 2, '2022-01-03', '16:30:00'),
(9, 4, '2022-01-13', '18:16:00'),
(10, 2, '2021-12-10', '18:11:00'),
(11, 2, '2022-02-11', '19:08:00'),
(12, 3, '2022-02-12', '14:50:00'),
(13, 4, '2022-03-19', '17:20:00'),
(14, 2, '2022-04-14', '19:01:00'),
(15, 3, '2022-01-28', '10:43:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cliente`
--

CREATE TABLE `cliente` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `edad` int(3) NOT NULL,
  `Dni_dueño` varchar(50) NOT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `cliente`
--

INSERT INTO `cliente` (`id`, `tipo`, `nombre`, `edad`, `Dni_dueño`, `foto`) VALUES
(12, 'Perro', 'tobi', 1, '111111111', 'cuartocliente.jpg'),
(13, 'gato', 'martin', 9, '222222222', 'clientegato1.jpg'),
(14, 'Perro', 'randy', 7, '333333333', 'dacowdogg.jpg'),
(15, 'nutria', 'luisa', 4, '222222222', 'nutria1.jpg'),
(16, 'Perro', 'habib', 3, '111111111', 'segundocliente.jpg'),
(17, 'Perro', 'pedro', 12, '444444444', 'tercercliente.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dueño`
--

CREATE TABLE `dueño` (
  `Dni` varchar(9) CHARACTER SET latin1 NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Telefono` int(9) NOT NULL,
  `nick` varchar(50) NOT NULL,
  `pass` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `dueño`
--

INSERT INTO `dueño` (`Dni`, `Nombre`, `Telefono`, `nick`, `pass`) VALUES
('00000000', 'Administrador', 0, 'admin', '21232f297a57a5a743894a0e4a801fc3'),
('111111111', 'raul', 111111, 'rual', 'bc7a844476607e1a59d8eb1b1f311830'),
('222222222', 'sonia', 222222, 'soniaa2', 'd31cb1e2b7902e8e9b4d1793e94c38a0'),
('333333333', 'victor', 333333, 'castorvistro', 'ffc150a160d37e92012c196b6af4160d'),
('444444444', 'Juanma', 444444, 'juanma', '65a368f66ad6b9ee45263577713d8a95');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticia`
--

CREATE TABLE `noticia` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `titulo` varchar(50) NOT NULL,
  `contenido` varchar(1000) NOT NULL,
  `imagen` varchar(100) NOT NULL,
  `fecha_publicacion` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `noticia`
--

INSERT INTO `noticia` (`id`, `titulo`, `contenido`, `imagen`, `fecha_publicacion`) VALUES
(19, 'DICIEMBRE: MES DE LA SALUD DE MASCOTAS GERIÁTRICAS', 'Para poder despejar todas estas dudas y poder ayudaros, durante el mes de Diciembre nos dedicamos a ellos, a los más mayores de la casa!! Como ya venimos realizando durante algunos años, con la campaña dedicada a los Geriátricos, intentamos ayudaros a anticiparnos a esos posibles «achaques» que pueden aparecer con la edad, a los que pueden ir surgiendo o incluso a los que ya tienen, pero que están empezando y los queremos frenar.\n', 'https://www.centroveterinarioalbayda.com/wp-content/uploads/2015/12/geriatrica.jpg', '2022-02-10'),
(20, 'NOVIEMBRE – CAMPAÑA DENTAL', 'En esta campaña os ofrecemos:\nConsulta de valoración dental gratuita.\n20% de descuento en limpiezas dentales.\nSe realizará un chequeo de gratuito para todos aquellos animales que se hagan su limpieza dental.\n', 'https://i0.wp.com/www.centroveterinarioalbayda.com/wp-content/uploads/2019/10/foto-02.jpg?fit=979%2C', '2022-02-10'),
(21, '¿Sabes lo que indica el tamaño de las pupilas?', 'Nuestro gatos, como buenos felinos, son animales tremendamente expresivos y una de las partes de su cuerpo que más nos dice cómo están o cómo se sienten son sus pupilas. El tamaño y la forma de esta parte de sus ojos, nos puede dar mucha información de su estado de ánimo en ese momento.\nUnas pupilas contraídas y cerradas , por lo general nos indican: felicidad,  interés , tensión o amenaza.\nUnas pupilas dilatadas y abiertas, suelen indicar: sorpresa, miedo o defensa.\n', 'https://www.centroveterinarioalbayda.com/wp-content/uploads/2018/04/gato-ojos.jpg', '2022-02-02'),
(22, 'Cinco consejos para cuidar conejos y roedores.', 'Para la jaula.\nDebe ser lo más grande posible. Esta característica suele depender del sitio que dispongas en casa.\nPara roedores lo más recomendable son las jaulas altas de varios niveles.\nRefugio o madriguera. A los conejos y roedores les gusta sentirse seguros, prepara una especie de refugio donde puedan esconderse y ofréceles materiales para que construyan su madriguera o nido.\nMantén una higiene diaria. La limpieza de la jaula es muy importante para evitar infecciones y malos olores. Cambia el sustrato sucio a diario y retira los restos de comida.\nElige un buen sustrato. Los mejores sustratos son los de madera prensada, maíz y papel reciclado. La viruta, serrín o tiras de papel no absorben bien la humedad, se apelmazan y eliminan polvo.\nEnriquece su medio. Coloca refugios, juguetes, cuerdas, hamacas… cualquier elemento que entretenga a la mascota.\n', 'https://www.vitalcan.es/wp-content/uploads/2020/08/hamster-5115249_1280.jpg', '2022-01-12'),
(23, '¿Tu perro es hiperactivo?', 'La hiperactividad en mascotas es una alteración fisiológica y del comportamiento y de carácter heredable, aunque puede tener su origen en causas no genéticas:\n\nBaja estimulación. El perro no recibe suficiente estimulación física y/o mental a diario.\nAprendizaje. El propietario refuerza las conductas excitables, de forma voluntaria o involuntaria.\nExceso de calorías en la dieta o hipersensibilidad nutricional.\nFalta de socialización. La ausencia de esta etapa en la educación del cachorro durante el periodo sensible suele ser la causa de muchos problemas de comportamiento en la vida adulta. También influye un destete temprano en los problemas de hiperactividad, algo que suele ocurrir con los perros procedentes de las tiendas de animales.\nFalta de rutina. Por norma general, los animales se muestran más nerviosos si no pueden predecir cuándo comer, dormir, salir…\n', 'https://www.consumer.es/app/uploads/2019/07/img_cachorro-nervioso-2.jpg', '2022-02-11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE `producto` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `precio` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `producto`
--

INSERT INTO `producto` (`id`, `nombre`, `precio`) VALUES
(7, 'HEPAFORT 1 L', '13.00'),
(8, 'CLX 4 % SOLUCION SPRAY 200 ML', '18.00'),
(9, 'SERAQUIN OMEGA 60 COMP MASTIC', '32.00'),
(10, 'xampu', '25.00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `descripcion` varchar(350) NOT NULL,
  `duracion` double(4,2) NOT NULL,
  `precio` double(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `servicio`
--

INSERT INTO `servicio` (`id`, `descripcion`, `duracion`, `precio`) VALUES
(2, 'Ecografía', 45.00, 24.00),
(3, 'Análisis de Triquina', 99.99, 36.00),
(4, 'Cirugía Tejidos Blandos', 99.99, 135.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `testimonio`
--

CREATE TABLE `testimonio` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Dni_autor` varchar(50) NOT NULL,
  `contenido` varchar(500) NOT NULL,
  `fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `testimonio`
--

INSERT INTO `testimonio` (`id`, `Dni_autor`, `contenido`, `fecha`) VALUES
(10, '111111111', 'Todo genial, me encanta el trato que da este centro.', '2022-01-23'),
(11, '333333333', 'Se nota que aman su trabajo. Mis mascotas siempre quieren volver.', '2022-01-23'),
(12, '444444444', 'El trato que reciben mis mascotas en este centro es inigualable!', '2022-01-23'),
(13, '222222222', 'Salta a la vista que es un equipo muy preparado y que se preocupan de verdad por los animales.', '2022-01-23');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `citas`
--
ALTER TABLE `citas`
  ADD PRIMARY KEY (`cliente`,`servicio`);

--
-- Indices de la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Dni_dueño` (`Dni_dueño`);

--
-- Indices de la tabla `dueño`
--
ALTER TABLE `dueño`
  ADD PRIMARY KEY (`Dni`);

--
-- Indices de la tabla `noticia`
--
ALTER TABLE `noticia`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `testimonio`
--
ALTER TABLE `testimonio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Dni_autor` (`Dni_autor`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `noticia`
--
ALTER TABLE `noticia`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `servicio`
--
ALTER TABLE `servicio`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `testimonio`
--
ALTER TABLE `testimonio`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`Dni_dueño`) REFERENCES `dueño` (`Dni`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `testimonio`
--
ALTER TABLE `testimonio`
  ADD CONSTRAINT `testimonio_ibfk_1` FOREIGN KEY (`Dni_autor`) REFERENCES `dueño` (`Dni`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
