"use strict"

// coger las cartas de las noticias por id
const cNoticias = document.querySelector("#cartaNoticias");

const nuevaNoticia = (dios) =>{

    const rowCarta = document.createElement("div");
    rowCarta.classList.add("row","webos");

    const colCarta = document.createElement("div");
    colCarta.classList.add("col");
    rowCarta.appendChild(colCarta);

    const divCarta = document.createElement("div");
    divCarta.classList.add("card","my-5");
    colCarta.appendChild(divCarta);

    const portada = document.createElement("img");
    portada.src= dios["foto"];
    portada.classList.add("card-img-top");
    divCarta.appendChild(portada);

    const cuerpoCarta = document.createElement("div");
    cuerpoCarta.classList.add("card-body");
    divCarta.appendChild(cuerpoCarta);

    const tituloCarta = document.createElement("h5");
    tituloCarta.classList.add("card-title");
    tituloCarta.innerText = dios["titulo"];
    cuerpoCarta.appendChild(tituloCarta);

    const contenidoCarta = document.createElement("p");
    contenidoCarta.classList.add("card-text");
    contenidoCarta.innerText = dios["contenido"];
    cuerpoCarta.appendChild(contenidoCarta);

    const fechaCarta = document.createElement("p");
    fechaCarta.classList.add("card-text");
    fechaCarta.innerText = dios["fecha_publicacion"];
    cuerpoCarta.appendChild(fechaCarta);

    return rowCarta;

}

const titulo = document.querySelector("#titulo");
const contenido = document.querySelector("#contenido");
const foto = document.querySelector("#foto");
const fecha = document.querySelector("#fecha_publicacion");

// Ajustes para que aparezca el formulario de añadir o quitarlo

const finalN = document.querySelector("#nuevo");

const formAñadir = document.querySelector("#insertar_f");

const añadirB = document.querySelector("#btnAñadir");
if(añadirB!=null){

    añadirB.addEventListener("click",
        ()=>{
            if(formAñadir.classList.contains("d-none")){
                formAñadir.classList.remove("d-none");
                añadirB.value="Cancelar";
            }else{
                formAñadir.classList.add("d-none");
                añadirB.value="Añadir noticia";
            }
        }
    );
}

// Para añadir una noticia y comprobar los datos
if(finalN!=null){

    finalN.addEventListener("click",async (suceso)=>{
        suceso.preventDefault();
        if(titulo.value.trim().length<4){
            
        }else if(contenido.value.trim().length<4){
            
        }else if(foto.value.trim().length<4){
            
        }else if(fecha.value.trim().length<4){
            
        }else if(sessionStorage.getItem("ID_" + titulo.value.trim().toUpperCase().replaceAll(" ", ""))!==null){
            
        }else{
    
    
            const datos_insercion = new URLSearchParams(new FormData(formAñadir));
            const respuesta=await fetch("insertarNoticia.php",
                {
                    method:"POST",
                    body:datos_insercion
                }
            );
    
            const eso = await respuesta.json();
    
            const info = {
                "id":eso.id,
                "titulo":titulo.value.trim(),
                "contenido":contenido.value.trim(),
                "foto":foto.value.trim(),
                "fecha_publicacion":fecha.value.trim(),
            };
    
            const estrenado = nuevaNoticia(info);
            cNoticias.appendChild(estrenado);
            sessionStorage.setItem("ID_"+titulo.value.trim().toUpperCase().replaceAll(" ", ""),JSON.stringify(info));
    
            formAñadir.reset();
            mensajeOK("Todo correcto, puede continuar.");
    
        }
    });

}




if(sessionStorage.length === 0){
    
    (async()=>{

        const respuesta = await fetch("noticiasConfig.php");

        const noticia = await respuesta.json();
        console.log("noticia");
 
        noticia.forEach(
            (algo)=>{
                sessionStorage.setItem("ID_"+algo["titulo"].toUpperCase().replaceAll(" ",""),JSON.stringify(algo));
              
            }
        )

        Object.values(sessionStorage).forEach(
            (algo)=>{
                cNoticias.appendChild(nuevaNoticia(JSON.parse(algo)));
            }
        )

    })();

}else{

    Object.values(sessionStorage).forEach(
        (algo)=>{
            cNoticias.appendChild(nuevaNoticia(JSON.parse(algo)));
        }
    )

}

const webo = document.querySelectorAll(".webos");

const lazy = new IntersectionObserver(
    dios=>{
        dios.forEach(
            (dio)=>{
                if(dio.isIntersecting){
                    dio.target.classList.add("sombra");
                }
            }
        )
    }
)

webo.forEach(
    (noticia)=>{
        lazy.observe(noticia)
    }
)