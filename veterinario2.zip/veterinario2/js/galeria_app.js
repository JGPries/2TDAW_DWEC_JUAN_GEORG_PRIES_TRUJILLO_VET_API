"use strict"

const galeriaE = document.querySelector("#galeriaExt");

(
    async()=>{

        for(let i=0;i<2;i++){

            const respuesta = await fetch("https://dog.ceo/api/breeds/image/random");
            const datos = await respuesta.json();

            const fotoRand = await datos["message"];
            galeriaE.appendChild(nuevoAnimal(fotoRand));

        }

        

})();


const nuevoAnimal = (url)=>{

    const rowGal = document.createElement("div");
    rowGal.classList.add("text-center");

    const colGal = document.createElement("div");
    colGal.classList.add("col-6");
    rowGal.appendChild(colGal);

    const divGrupo = document.createElement("div");
    divGrupo.classList.add("card-group");
    colGal.appendChild(divGrupo);

    const divCard = document.createElement("div");
    divCard.classList.add("card");
    divCard.style.textAlign='center';
    divGrupo.appendChild(divCard);

    const fotoPerro = document.createElement("img");
    fotoPerro.src= url;
    fotoPerro.classList.add("card-img-top");
    fotoPerro.style.margin=15+'px';
    fotoPerro.style.maxWidth=450+'px';
    fotoPerro.style.maxHeight=450+'px';
    fotoPerro.style.minWidth=450+'px';
    fotoPerro.style.minHeight=450+'px';
    divCard.appendChild(fotoPerro);

    return rowGal;

}