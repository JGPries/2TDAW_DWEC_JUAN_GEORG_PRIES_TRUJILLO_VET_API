<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VET</title>
    <!-- Conectar a css -->
    <link rel="stylesheet" type="text/css" href="css/stylo.css">
    <!-- Favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon-16x16.png">
    <link rel="manifest" href="assets/site.webmanifest">
    <!--Para las imagenes del menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="preconnect" href="https://fonts.gstatic.com">
</head>
<body>

    <?php
        require_once("php/funciones.php");

        $conexion=conectar();

        $parametro1="";
        $parametro2="php/";
        generador_menu($parametro1,$parametro2);

    ?>

    <header>
        <img id="fondopant" src="assets/fondopantalla2.jpg" style="z-index:-5;">
    </header>

    <main class="maindiv">

        <h2 class="titindex">NOTICIAS</h2>
        <hr>

        <?php

            $sentencia="SELECT * from noticia ORDER BY fecha_publicacion ASC limit 1, 3";
            $datos= $conexion->query($sentencia);

            if(!$datos){
                echo"Error";
            }else{

                if($datos->num_rows <=0){
                    echo"<br> <h2>No hay noticias para mostrar</h2>";
                }else{
                    while($fila=$datos->fetch_array(MYSQLI_BOTH)){

                        echo
                            "<section id='artnoticia'>
                                <article>
                                    <img src='assets/$fila[imagen]'>
                                    <h2>$fila[titulo]</h2>
                                    <p class='contenidonoticia'>$fila[contenido]<p>
                                    <p>$fila[fecha_publicacion]</p>
                                </article>
                            </section>
                            ";
                    }
                }
            }

        ?>

        <div>
            <h2 class="titindex">Testimonios</h2>
            <hr>

        </div>

        <?php

            $totalTesti="SELECT d.Nombre, t.contenido, t.fecha from testimonio t, dueño d where d.Dni = t.Dni_autor order by rand() limit 1";
            $datos1=$conexion->query($totalTesti);

            if(!$datos1){
                echo"Error";
            }else{

                if($datos1->num_rows <=0){
                    echo"<br> <h2>No hay testimonios para mostrar</h2>";
                }else{

                    echo
                            "<table id='tablacli'>
                                <tr>
                                    <th>AUTOR</th>
                                    <th>CONTENIDO</th>
                                    <th>FECHA</th>
                                </tr>
                            ";

                    while($fila=$datos1->fetch_array(MYSQLI_BOTH)){

                        echo
                            "<tr>
                                <td>$fila[Nombre]</td>
                                <td>$fila[contenido]</td>
                                <td>$fila[fecha]</td>
                            </tr>
                            ";
                    }
                    echo"</table>";
                }
            }

        ?>

        <h2 class="titindex">Contacto</h2>

        <form id="formnoticia" action="#" method="POST" enctype="multipart/form-data">

            Introduce tu Nombre.
            <input type="text" name="nick" required>
            <br>
            Tu Apellido.
            <input type="text" name="nick" required>
            <br>
            Introduce tu telefono de contacto.
            <input type="number" name="nick" required>
            <br>
            Explicanos el motivo por el cual nos quieres contactar.<br>
            <textarea rows="10" cols="60" maxlength="1000" name="contenido" required></textarea>
            <br>
            <input type="submit" value="enviar" name="enviar">

        </form>

    </main>

    <?php
        
        generador_footer($parametro1,$parametro2);

        $conexion=desconectar();

    ?>
    
</body>
</html>